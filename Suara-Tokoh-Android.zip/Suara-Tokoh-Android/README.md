# Suara Tokoh

Asisten salin-tempel untuk Google AI Studio TTS (tanpa API key).

- Pembukaan pertama: pilih & kunci suara narator.
- Naskah format `Nama: dialog`; baris tanpa nama = narator; tipe opsional `Adi (anak): ...`.
- Suara tokoh lain dipilih otomatis sesuai tipe (lelaki tua, anak, gadis, dll.) dan dikunci agar selalu sama.
- Tab BLOK: salin style & teks per blok, lalu tempel di AI Studio.

Build APK: unggah zip proyek + `.github/workflows/build-apk.yml`, lalu ambil artifact di tab Actions.
