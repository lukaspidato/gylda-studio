package com.suaratokoh.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val AI_STUDIO_URL = "https://aistudio.google.com/generate-speech"

enum class VoiceType(val label: String, val style: String) {
    NARATOR("Narator", "Bacakan sebagai narator cerita yang ramah, tenang, dan hangat, dengan jeda alami."),
    LELAKI_TUA("Lelaki tua", "Suara lelaki tua yang berat dan berwibawa, bicara pelan dan tenang."),
    PEREMPUAN_TUA("Perempuan tua", "Suara perempuan tua yang lembut namun tegas, bicara pelan."),
    LELAKI_DEWASA("Lelaki dewasa", "Suara lelaki dewasa yang tegas dan jelas."),
    PEREMPUAN_DEWASA("Perempuan dewasa", "Suara perempuan dewasa yang hangat dan jelas."),
    PEMUDA("Pemuda", "Suara pemuda yang bersemangat dan santai."),
    PEMUDI("Pemudi", "Suara gadis muda yang ceria dan ekspresif."),
    ANAK("Anak-anak", "Suara anak-anak yang polos dan riang, tempo sedikit cepat.")
}

data class GeminiVoice(val name: String, val gender: String, val trait: String)

object Voices {
    val all = listOf(
        GeminiVoice("Achird", "Lelaki", "Friendly"),
        GeminiVoice("Achernar", "Perempuan", "Soft"),
        GeminiVoice("Algenib", "Lelaki", "Gravelly"),
        GeminiVoice("Algieba", "Lelaki", "Smooth"),
        GeminiVoice("Alnilam", "Lelaki", "Firm"),
        GeminiVoice("Aoede", "Perempuan", "Breezy"),
        GeminiVoice("Autonoe", "Perempuan", "Bright"),
        GeminiVoice("Callirrhoe", "Perempuan", "Easy-going"),
        GeminiVoice("Charon", "Lelaki", "Informative"),
        GeminiVoice("Despina", "Perempuan", "Smooth"),
        GeminiVoice("Enceladus", "Lelaki", "Breathy"),
        GeminiVoice("Erinome", "Perempuan", "Clear"),
        GeminiVoice("Fenrir", "Lelaki", "Excitable"),
        GeminiVoice("Gacrux", "Perempuan", "Mature"),
        GeminiVoice("Iapetus", "Lelaki", "Clear"),
        GeminiVoice("Kore", "Perempuan", "Firm"),
        GeminiVoice("Laomedeia", "Perempuan", "Upbeat"),
        GeminiVoice("Leda", "Perempuan", "Youthful"),
        GeminiVoice("Orus", "Lelaki", "Firm"),
        GeminiVoice("Puck", "Lelaki", "Upbeat"),
        GeminiVoice("Pulcherrima", "Perempuan", "Forward"),
        GeminiVoice("Rasalgethi", "Lelaki", "Informative"),
        GeminiVoice("Sadachbia", "Lelaki", "Lively"),
        GeminiVoice("Sadaltager", "Lelaki", "Knowledgeable"),
        GeminiVoice("Schedar", "Lelaki", "Even"),
        GeminiVoice("Sulafat", "Perempuan", "Warm"),
        GeminiVoice("Umbriel", "Lelaki", "Easy-going"),
        GeminiVoice("Vindemiatrix", "Perempuan", "Gentle"),
        GeminiVoice("Zephyr", "Perempuan", "Bright"),
        GeminiVoice("Zubenelgenubi", "Lelaki", "Casual")
    )

    private val pools: Map<VoiceType, List<String>> = mapOf(
        VoiceType.NARATOR to listOf("Achird", "Sulafat", "Charon", "Iapetus", "Schedar"),
        VoiceType.LELAKI_TUA to listOf("Algenib", "Rasalgethi", "Sadaltager", "Charon", "Iapetus", "Alnilam"),
        VoiceType.PEREMPUAN_TUA to listOf("Gacrux", "Vindemiatrix", "Sulafat", "Achernar"),
        VoiceType.LELAKI_DEWASA to listOf("Orus", "Alnilam", "Schedar", "Umbriel", "Iapetus", "Charon"),
        VoiceType.PEREMPUAN_DEWASA to listOf("Kore", "Despina", "Erinome", "Callirrhoe", "Pulcherrima"),
        VoiceType.PEMUDA to listOf("Puck", "Fenrir", "Zubenelgenubi", "Enceladus", "Algieba", "Achird"),
        VoiceType.PEMUDI to listOf("Aoede", "Zephyr", "Autonoe", "Laomedeia", "Despina"),
        VoiceType.ANAK to listOf("Leda", "Sadachbia", "Laomedeia", "Puck")
    )

    fun find(name: String): GeminiVoice? = all.firstOrNull { it.name.equals(name, ignoreCase = true) }
    fun label(name: String): String = find(name)?.let { "${it.name} · ${it.trait} · ${it.gender}" } ?: name
    fun pool(type: VoiceType): List<String> = pools[type] ?: listOf("Achird")
}

object TypeDetector {
    private val rules: List<Pair<VoiceType, List<String>>> = listOf(
        VoiceType.NARATOR to listOf("narator", "narasi", "narrator", "pencerita", "pendongeng"),
        VoiceType.ANAK to listOf("anak", "adik", "dik", "bocah", "kecil", "tole", "thole", "nduk", "bayi", "cucu", "bocil", "balita", "bocah cilik"),
        VoiceType.PEREMPUAN_TUA to listOf("nenek", "mbah putri", "eyang putri", "mbah wedok", "mbok", "nini", "nyai", "oma", "bude", "budhe", "emak", "mak", "perempuan tua", "wanita tua", "ibu tua"),
        VoiceType.LELAKI_TUA to listOf("kakek", "kakung", "mbah", "eyang", "aki", "engkong", "opa", "datuk", "pak", "bapak", "pakde", "haji", "kyai", "kiai", "abah", "rt", "rw", "lurah", "kades", "dukun", "juragan", "tua", "sesepuh"),
        VoiceType.PEMUDI to listOf("mbak", "teh", "neng", "gadis", "nona", "dara", "cewek", "perawan", "perempuan muda", "wanita muda", "remaja putri"),
        VoiceType.PEMUDA to listOf("mas", "kang", "bang", "abang", "pemuda", "cowok", "bujang", "jaka", "perjaka", "lelaki muda", "remaja", "pria muda"),
        VoiceType.PEREMPUAN_DEWASA to listOf("ibu", "bu", "bunda", "umi", "tante", "bibi", "istri", "perempuan", "wanita"),
        VoiceType.LELAKI_DEWASA to listOf("ayah", "om", "paman", "lelaki", "pria", "suami", "polisi", "satpam", "dewasa")
    )

    fun detect(text: String): VoiceType? {
        if (text.isBlank()) return null
        val n = " " + text.lowercase().replace(Regex("[^a-z ]"), " ").replace(Regex("\\s+"), " ").trim() + " "
        for ((type, keys) in rules) {
            if (keys.any { n.contains(" $it ") }) return type
        }
        return null
    }
}

data class Block(val speaker: String, val hint: String, val text: String)

object ScriptParser {
    const val NARRATOR = "Narator"
    private val head = Regex("^([^:]{1,60}):\\s*(.*)$")
    private val paren = Regex("\\(([^)]*)\\)")

    fun parse(script: String): List<Block> {
        val raw = mutableListOf<Block>()
        script.lines().forEach { line ->
            val t = line.trim()
            if (t.isEmpty()) return@forEach
            val m = head.matchEntire(t)
            var added = false
            if (m != null) {
                val headText = m.groupValues[1].trim()
                val body = m.groupValues[2].trim()
                val hint = paren.find(headText)?.groupValues?.get(1)?.trim().orEmpty()
                var name = paren.replace(headText, "").replace(Regex("\\s+"), " ").trim()
                val words = if (name.isEmpty()) 0 else name.split(" ").size
                if (name.isNotEmpty() && words <= 4 && body.isNotEmpty()) {
                    if (TypeDetector.detect(name) == VoiceType.NARATOR) name = NARRATOR
                    raw += Block(name, hint, body)
                    added = true
                }
            }
            if (!added) raw += Block(NARRATOR, "", t)
        }

        val merged = mutableListOf<Block>()
        raw.forEach { b ->
            val last = merged.lastOrNull()
            if (last != null && last.speaker.equals(b.speaker, ignoreCase = true) && last.text.length + b.text.length < 2500) {
                merged[merged.size - 1] = last.copy(text = last.text + "\n" + b.text, hint = last.hint.ifBlank { b.hint })
            } else {
                merged += b
            }
        }
        return merged
    }
}

data class CharacterVoice(
    val name: String,
    val type: VoiceType,
    val voice: String,
    val style: String,
    val locked: Boolean = true,
    val guessed: Boolean = false
) {
    val key: String get() = keyOf(name)

    companion object {
        fun keyOf(name: String): String = name.trim().lowercase()
    }
}

object Assigner {
    fun pickVoice(type: VoiceType, all: List<CharacterVoice>, selfKey: String): String {
        val used = all.filter { it.key != selfKey }.map { it.voice.lowercase() }.toSet()
        val pool = Voices.pool(type)
        return pool.firstOrNull { it.lowercase() !in used } ?: pool.first()
    }

    fun assign(blocks: List<Block>, existing: List<CharacterVoice>): List<CharacterVoice> {
        val result = existing.toMutableList()
        blocks.forEach { b ->
            val key = CharacterVoice.keyOf(b.speaker)
            if (result.none { it.key == key }) {
                val detected = TypeDetector.detect(b.hint) ?: TypeDetector.detect(b.speaker)
                val type = detected ?: VoiceType.LELAKI_DEWASA
                val voice = pickVoice(type, result, key)
                result += CharacterVoice(b.speaker, type, voice, type.style, locked = true, guessed = detected == null)
            }
        }
        return result
    }
}

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("suara_tokoh", Context.MODE_PRIVATE)

    var script: String
        get() = prefs.getString("script", "") ?: ""
        set(value) { prefs.edit().putString("script", value).apply() }

    fun loadCharacters(): List<CharacterVoice> {
        val saved = prefs.getString("characters", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(saved)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                CharacterVoice(
                    name = o.getString("name"),
                    type = runCatching { VoiceType.valueOf(o.getString("type")) }.getOrDefault(VoiceType.LELAKI_DEWASA),
                    voice = o.getString("voice"),
                    style = o.optString("style"),
                    locked = o.optBoolean("locked", true),
                    guessed = o.optBoolean("guessed", false)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveCharacters(list: List<CharacterVoice>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(
                JSONObject()
                    .put("name", c.name)
                    .put("type", c.type.name)
                    .put("voice", c.voice)
                    .put("style", c.style)
                    .put("locked", c.locked)
                    .put("guessed", c.guessed)
            )
        }
        prefs.edit().putString("characters", arr.toString()).apply()
    }
}
