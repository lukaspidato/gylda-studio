package com.suaratokoh.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Neon = Color(0xFF39FF14)
val Ink = Color(0xFF000000)
val Panel = Color(0xFF0A0A0A)
val Dim = Color(0xFF9A9A9A)
val Warn = Color(0xFFFFD54F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Neon,
                    onPrimary = Ink,
                    secondary = Neon,
                    background = Ink,
                    surface = Panel,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
                    App(store)
                }
            }
        }
    }
}

private const val NARRATOR_KEY = "narator"

@Composable
fun App(store: Store) {
    val characters = remember { mutableStateListOf<CharacterVoice>().apply { addAll(store.loadCharacters()) } }
    var showSetup by remember { mutableStateOf(characters.none { it.key == NARRATOR_KEY }) }
    val save: () -> Unit = { store.saveCharacters(characters.toList()) }

    if (showSetup) {
        SetupScreen(current = characters.firstOrNull { it.key == NARRATOR_KEY }) { voice, style ->
            val narrator = CharacterVoice(ScriptParser.NARRATOR, VoiceType.NARATOR, voice, style, locked = true, guessed = false)
            val idx = characters.indexOfFirst { it.key == NARRATOR_KEY }
            if (idx >= 0) characters[idx] = narrator else characters.add(0, narrator)
            save()
            showSetup = false
        }
    } else {
        MainScreen(store, characters, save, onChangeNarrator = { showSetup = true })
    }
}

@Composable
fun SetupScreen(current: CharacterVoice?, onDone: (String, String) -> Unit) {
    var selected by remember { mutableStateOf(current?.voice ?: "Achird") }
    var style by remember { mutableStateOf(current?.style ?: VoiceType.NARATOR.style) }

    Column(
        modifier = Modifier.fillMaxSize().imePadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("SUARA TOKOH", color = Neon, fontWeight = FontWeight.Black, fontSize = 24.sp, letterSpacing = 3.sp)
        Text(
            "Langkah pertama: pilih dan kunci suara NARATOR. Suara tokoh lain akan dipilihkan otomatis sesuai karakternya.",
            color = Color.White,
            fontSize = 14.sp
        )
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Voices.all) { v ->
                val isSelected = v.name == selected
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) Neon else Neon.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .background(if (isSelected) Neon.copy(alpha = 0.12f) else Panel, RoundedCornerShape(10.dp))
                        .clickable { selected = v.name }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(v.name, color = if (isSelected) Neon else Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("${v.trait} · ${v.gender}", color = Dim, fontSize = 12.sp)
                    }
                    if (v.name == "Achird") {
                        Text("REKOMENDASI", color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    if (isSelected) {
                        Text("  ✓", color = Neon, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    }
                }
            }
        }
        NeonField(value = style, onChange = { style = it }, label = "Style narator", minLines = 2)
        NeonButton(text = "KUNCI SUARA NARATOR: $selected", filled = true, modifier = Modifier.fillMaxWidth()) {
            onDone(selected, style.trim())
        }
    }
}

@Composable
fun MainScreen(
    store: Store,
    characters: SnapshotStateList<CharacterVoice>,
    save: () -> Unit,
    onChangeNarrator: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var script by remember { mutableStateOf(store.script) }
    var blocks by remember { mutableStateOf(ScriptParser.parse(store.script)) }
    var done by remember { mutableStateOf(setOf<Int>()) }
    val narrator = characters.firstOrNull { it.key == NARRATOR_KEY }

    Column(modifier = Modifier.fillMaxSize().imePadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("SUARA TOKOH", color = Neon, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 3.sp)
                Text("Asisten salin-tempel Google AI Studio TTS", color = Dim, fontSize = 11.sp)
            }
            Text(
                text = "NARATOR\n${narrator?.voice ?: "-"}",
                color = Neon,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .border(1.dp, Neon, RoundedCornerShape(8.dp))
                    .clickable { onChangeNarrator() }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
        TabRow(selectedTabIndex = tab, containerColor = Ink, contentColor = Neon) {
            listOf("NASKAH", "KARAKTER", "BLOK (${blocks.size})").forEachIndexed { i, title ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    selectedContentColor = Neon,
                    unselectedContentColor = Dim
                )
            }
        }
        HorizontalDivider(color = Neon, thickness = 1.dp)
        Box(modifier = Modifier.weight(1f)) {
            when (tab) {
                0 -> ScriptTab(
                    script = script,
                    onScriptChange = { script = it },
                    onProcess = {
                        store.script = script
                        val parsed = ScriptParser.parse(script)
                        blocks = parsed
                        done = emptySet()
                        val updated = Assigner.assign(parsed, characters.toList())
                        characters.clear()
                        characters.addAll(updated)
                        save()
                        val speakers = parsed.map { CharacterVoice.keyOf(it.speaker) }.toSet()
                        tab = if (updated.any { it.guessed && it.key in speakers }) 1 else 2
                    },
                    onChangeNarrator = onChangeNarrator
                )
                1 -> CharactersTab(characters, blocks, save)
                else -> BlocksTab(
                    blocks = blocks,
                    characters = characters,
                    done = done,
                    onToggleDone = { i -> done = if (i in done) done - i else done + i }
                )
            }
        }
    }
}

@Composable
fun ScriptTab(
    script: String,
    onScriptChange: (String) -> Unit,
    onProcess: () -> Unit,
    onChangeNarrator: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Tempel naskah di bawah. Satu dialog per baris dengan format  Nama: dialog", color = Color.White, fontSize = 14.sp)
        NeonBox {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("CONTOH", color = Neon, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(
                    "Malam itu kampung sangat sepi.\nPak RT: Siapa di luar?\nAdi (anak): Saya, Pak!\nBu Sari: Adi, cepat pulang!",
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
                Text(
                    "• Baris tanpa nama otomatis dibaca narator.\n• Tulis tipe di dalam kurung bila perlu: (anak), (lelaki tua), (gadis), (nenek).",
                    color = Dim,
                    fontSize = 12.sp
                )
            }
        }
        NeonField(value = script, onChange = onScriptChange, label = "Naskah", minLines = 10)
        NeonButton(text = "PROSES NASKAH", filled = true, modifier = Modifier.fillMaxWidth()) { onProcess() }
        NeonButton(text = "GANTI SUARA NARATOR", modifier = Modifier.fillMaxWidth()) { onChangeNarrator() }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun CharactersTab(characters: SnapshotStateList<CharacterVoice>, blocks: List<Block>, save: () -> Unit) {
    val speakers = blocks.map { CharacterVoice.keyOf(it.speaker) }.toSet()
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "Suara tiap tokoh DIKUNCI agar selalu sama di setiap blok. Geser saklar untuk membuka kunci dan mengubahnya.",
                color = Color.White,
                fontSize = 13.sp
            )
        }
        itemsIndexed(characters.toList()) { index, c ->
            CharacterCard(
                character = c,
                inScript = c.key in speakers,
                all = characters.toList(),
                onChange = { updated ->
                    if (index < characters.size) {
                        characters[index] = updated
                        save()
                    }
                },
                onDelete = if (c.key == NARRATOR_KEY) null else {
                    {
                        characters.removeAll { it.key == c.key }
                        save()
                    }
                }
            )
        }
    }
}

@Composable
fun CharacterCard(
    character: CharacterVoice,
    inScript: Boolean,
    all: List<CharacterVoice>,
    onChange: (CharacterVoice) -> Unit,
    onDelete: (() -> Unit)?
) {
    val c = character
    NeonBox {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(c.name, color = Neon, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        (if (c.locked) "🔒 TERKUNCI" else "🔓 TERBUKA") + if (inScript) "" else "  · tidak ada di naskah ini",
                        color = Dim,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = c.locked,
                    onCheckedChange = { onChange(c.copy(locked = it, guessed = if (it) false else c.guessed)) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Ink,
                        checkedTrackColor = Neon,
                        uncheckedThumbColor = Dim,
                        uncheckedTrackColor = Panel,
                        uncheckedBorderColor = Neon
                    )
                )
            }
            if (c.guessed) {
                Text(
                    "⚠ Tipe suara hanya tebakan dari nama. Buka kunci lalu pilih tipe yang benar (mis. Anak-anak).",
                    color = Warn,
                    fontSize = 12.sp
                )
            }
            Picker(
                label = "Tipe",
                value = c.type.label,
                options = VoiceType.values().map { it.name to it.label },
                enabled = !c.locked
            ) { key ->
                val type = VoiceType.valueOf(key)
                onChange(c.copy(type = type, voice = Assigner.pickVoice(type, all, c.key), style = type.style, guessed = false))
            }
            Picker(
                label = "Suara",
                value = Voices.label(c.voice),
                options = Voices.all.map { it.name to "${it.name} · ${it.trait} · ${it.gender}" },
                enabled = !c.locked
            ) { v ->
                onChange(c.copy(voice = v, guessed = false))
            }
            NeonField(
                value = c.style,
                onChange = { onChange(c.copy(style = it)) },
                label = "Style",
                enabled = !c.locked,
                minLines = 2
            )
            if (onDelete != null && !c.locked) {
                NeonButton(text = "HAPUS TOKOH", modifier = Modifier.fillMaxWidth()) { onDelete() }
            }
        }
    }
}

@Composable
fun BlocksTab(
    blocks: List<Block>,
    characters: List<CharacterVoice>,
    done: Set<Int>,
    onToggleDone: (Int) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            NeonBox {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("CARA PAKAI", color = Neon, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(
                        "1. Buka AI Studio sekali saja (mode Single-speaker).\n" +
                            "2. SALIN STYLE → tempel di kolom Style instructions.\n" +
                            "3. Pilih voice sesuai label SUARA di blok.\n" +
                            "4. SALIN TEKS → tempel di kolom teks, lalu Run.\n" +
                            "5. Kembali ke aplikasi ini (tombol aplikasi terbaru), tandai selesai, lanjut blok berikutnya.",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                    NeonButton(text = "BUKA GOOGLE AI STUDIO", filled = true, modifier = Modifier.fillMaxWidth()) {
                        openUrl(context, AI_STUDIO_URL)
                    }
                    Text("Selesai: ${done.size} / ${blocks.size} blok", color = Neon, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        if (blocks.isEmpty()) {
            item {
                Text("Belum ada blok. Tempel naskah di tab NASKAH lalu tekan PROSES NASKAH.", color = Dim, fontSize = 13.sp)
            }
        }
        itemsIndexed(blocks) { i, b ->
            val c = characters.firstOrNull { it.key == CharacterVoice.keyOf(b.speaker) }
            val isDone = i in done
            val voice = c?.voice ?: "-"
            val trait = Voices.find(voice)?.trait.orEmpty()
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = if (isDone) 1.dp else 2.dp,
                        color = if (isDone) Neon.copy(alpha = 0.3f) else Neon,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .background(Panel, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("#${i + 1}", color = Neon, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        b.speaker.uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (isDone) Text("✓ SELESAI", color = Neon, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text(
                    "SUARA: $voice" + if (trait.isNotEmpty()) "  ·  $trait" else "",
                    color = Neon,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text("STYLE: ${c?.style.orEmpty()}", color = Dim, fontSize = 12.sp)
                Text(
                    b.text,
                    color = if (isDone) Dim else Color.White,
                    fontSize = 14.sp,
                    maxLines = 8,
                    overflow = TextOverflow.Ellipsis
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton(text = "SALIN STYLE", modifier = Modifier.weight(1f)) {
                        clipboard.setText(AnnotatedString(c?.style.orEmpty()))
                        toast(context, "Style ${b.speaker} disalin")
                    }
                    NeonButton(text = "SALIN TEKS", filled = true, modifier = Modifier.weight(1f)) {
                        clipboard.setText(AnnotatedString(b.text))
                        toast(context, "Teks blok #${i + 1} disalin · pakai suara $voice")
                    }
                }
                NeonButton(
                    text = if (isDone) "BATAL SELESAI" else "TANDAI SELESAI",
                    modifier = Modifier.fillMaxWidth()
                ) { onToggleDone(i) }
            }
        }
    }
}

@Composable
fun NeonBox(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, Neon, RoundedCornerShape(12.dp))
            .background(Panel, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) { content() }
}

@Composable
fun NeonButton(
    text: String,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    if (filled) {
        Button(
            onClick = onClick,
            modifier = modifier,
            enabled = enabled,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Neon,
                contentColor = Ink,
                disabledContainerColor = Neon.copy(alpha = 0.3f),
                disabledContentColor = Ink
            )
        ) { Text(text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
    } else {
        OutlinedButton(
            onClick = onClick,
            modifier = modifier,
            enabled = enabled,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.5.dp, if (enabled) Neon else Neon.copy(alpha = 0.3f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Neon, disabledContentColor = Dim)
        ) { Text(text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
    }
}

@Composable
fun NeonField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    enabled: Boolean = true,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        enabled = enabled,
        label = { Text(label) },
        minLines = minLines,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Neon,
            unfocusedBorderColor = Neon.copy(alpha = 0.5f),
            disabledBorderColor = Neon.copy(alpha = 0.2f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            disabledTextColor = Dim,
            cursorColor = Neon,
            focusedLabelColor = Neon,
            unfocusedLabelColor = Dim,
            disabledLabelColor = Dim,
            focusedContainerColor = Panel,
            unfocusedContainerColor = Panel,
            disabledContainerColor = Panel
        )
    )
}

@Composable
fun Picker(
    label: String,
    value: String,
    options: List<Pair<String, String>>,
    enabled: Boolean,
    onPick: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        NeonButton(text = "$label: $value  ▾", modifier = Modifier.fillMaxWidth(), enabled = enabled) { open = true }
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            modifier = Modifier.background(Panel)
        ) {
            options.forEach { (key, text) ->
                DropdownMenuItem(
                    text = { Text(text, color = Color.White) },
                    onClick = {
                        open = false
                        onPick(key)
                    }
                )
            }
        }
    }
}

fun toast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}

fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: Exception) {
        toast(context, "Tidak ada browser untuk membuka AI Studio")
    }
}
