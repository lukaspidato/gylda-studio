# AI Drama Studio — Android source project

**Versi:** 0.1.0 (MVP source)

Aplikasi Android pribadi untuk mengubah naskah dialog menjadi audio drama dengan banyak karakter. Mendukung dua provider:

- **ElevenLabs Text to Dialogue** — pilihan utama untuk 4–6 karakter. API menerima hingga 10 voice ID unik per request; aplikasi memecah naskah otomatis menjadi bagian sekitar 1.750 karakter dan menggabungkan hasil MP3.
- **Google Gemini TTS** — mendukung maksimal 2 speaker dalam satu request multi-speaker. Aplikasi membagi naskah otomatis; setiap bagian harus berisi maksimal dua karakter. Hasil WAV digabung menjadi satu WAV.

## Fitur MVP

- Input naskah dengan format `Nama Tokoh: dialog`.
- Pemetaan nama tokoh ke ElevenLabs Voice ID atau Gemini voice.
- Dukungan enam karakter awal dan tombol tambah karakter.
- Pemilihan mesin suara per proyek.
- Pemotongan naskah otomatis per dialog agar request tidak terlalu besar.
- Progress proses pembuatan audio.
- Penggabungan hasil menjadi satu file MP3 (ElevenLabs) atau WAV (Gemini).
- Penyimpanan hasil ke `Music/AI Drama Studio` melalui MediaStore.
- API key disimpan terenkripsi menggunakan Android Keystore AES-GCM.

## Kebutuhan

- Android Studio versi terbaru yang mendukung Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.
- Koneksi internet.
- API key milik sendiri dari ElevenLabs dan/atau Google AI Studio.

## Cara membuka dan membangun APK

1. Ekstrak folder proyek.
2. Buka Android Studio.
3. Pilih **Open** lalu pilih folder `AI-Drama-Studio-Android`.
4. Pastikan Android SDK Platform 35 dan JDK 17 tersedia.
5. Tunggu Gradle Sync selesai. Android Studio akan mengunduh dependensi Gradle yang diperlukan.
6. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Untuk membuat APK rilis: **Build → Generate Signed Bundle / APK → APK**, lalu buat atau pilih keystore milik sendiri.

## Mengatur API key di aplikasi

1. Buka aplikasi di perangkat Android.
2. Masukkan ElevenLabs API key dan/atau Google Gemini API key di bagian **Kunci API**.
3. Tekan **Simpan kunci API dengan aman**.
4. Isi Voice ID untuk ElevenLabs. Voice ID didapat dari akun/Voice Library ElevenLabs.
5. Untuk Gemini, gunakan nama voice yang didukung Gemini TTS, misalnya `Kore`, `Puck`, `Charon`, `Aoede`, `Fenrir`, atau `Zephyr`.

Jangan kirim API key ke percakapan atau membagikannya di tempat umum. Aplikasi ini menyimpan kunci terenkripsi secara lokal. Untuk aplikasi yang akan dibagikan ke publik atau digunakan banyak orang, arsitektur yang disarankan adalah backend HTTPS agar API key provider tidak berada di perangkat pengguna.

## Format naskah

Gunakan satu dialog per baris:

```text
Perempuan muda: Nenek, siapa yang tinggal di rumah belakang itu?
Perempuan tua: Jangan pernah mendekati rumah itu.
Pemuda: Kenapa? Memangnya ada sesuatu di sana?
Kakek: Kalian belum tahu apa yang terjadi tiga puluh tahun lalu.
Narator: Malam itu, hujan turun semakin deras.
```

Nama di sebelah kiri titik dua harus sama persis dengan nama karakter pada bagian **Atur karakter dan suara**. Baris tanpa pola `Nama: dialog` setelah sebuah dialog akan ditambahkan sebagai lanjutan dialog sebelumnya.

## Batasan MVP yang perlu diketahui

- Untuk drama 4–6 karakter, gunakan ElevenLabs. Dokumentasi endpoint Text to Dialogue membatasi 10 voice ID unik dan menyarankan total teks maksimal 2.000 karakter per request; aplikasi menggunakan batas internal lebih konservatif sekitar 1.750 karakter.
- Gemini multi-speaker mendukung maksimal 2 speaker per request. Jika satu bagian naskah berisi lebih dari dua tokoh, aplikasi akan menampilkan pesan agar bagian itu dibuat dengan ElevenLabs atau naskah dibagi menjadi adegan yang lebih kecil.
- ElevenLabs menghasilkan MP3. Penggabungan dilakukan dengan menghapus tag metadata ID3 antarbagian lalu menyambung frame audio; hasil perlu diuji pada perangkat pemutar yang digunakan.
- Gemini menghasilkan WAV. Penggabungan WAV pada MVP mengasumsikan audio PCM dengan header WAV standar 44 byte dan format konsisten antarbagian.
- MVP ini belum menyediakan editor timeline, musik latar, efek suara, pengaturan jeda visual, riwayat proyek, maupun sinkronisasi cloud.
- Durasi 30 menit adalah target penggunaan, bukan jaminan. Lama proses dan biaya bergantung pada panjang naskah, jumlah bagian, provider, paket, dan kuota API.

## Struktur kode

- `MainActivity.kt` — UI Compose, input naskah, karakter, API key, progress, dan penyimpanan audio.
- `TtsClient.kt` — integrasi REST ElevenLabs dan Gemini TTS.
- `DramaModels.kt` — model data, parser naskah, dan pemotongan dialog.
- `AudioJoiner.kt` — penggabungan MP3/WAV.
- `SecureStore.kt` — penyimpanan API key terenkripsi Android Keystore.

## Catatan build

Lingkungan pembuatan arsip ini tidak memiliki Android SDK/Gradle yang terpasang dan tidak dapat mengunduh dependensi build. Karena itu, arsip ini adalah **proyek sumber Android Studio**, bukan APK yang sudah dikompilasi atau diuji pada perangkat. APK perlu dibangun melalui Android Studio mengikuti langkah di atas.

## Build APK lewat browser (GitHub Actions)

1. Buat repository GitHub baru, misalnya `ai-drama-studio`.
2. Upload seluruh isi folder proyek ini ke root repository (termasuk folder `.github`).
3. Buka tab **Actions** pada repository dan aktifkan Actions jika diminta.
4. Pilih workflow **Build AI Drama Studio APK**.
5. Tekan **Run workflow** dan tunggu sampai proses selesai.
6. Buka hasil run yang berstatus sukses, lalu unduh artifact `ai-drama-studio-debug-apk`.
7. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

Workflow ini menggunakan Java 17, Android SDK 35, dan Gradle 8.9 di runner cloud GitHub. File yang dihasilkan adalah APK debug untuk pengujian, bukan APK release bertanda tangan untuk distribusi publik.
