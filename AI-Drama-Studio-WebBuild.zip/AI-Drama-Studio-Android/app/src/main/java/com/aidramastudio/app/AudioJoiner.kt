package com.aidramastudio.app

import java.io.ByteArrayOutputStream

object AudioJoiner {
    fun joinMp3(parts: List<ByteArray>): ByteArray {
        val output = ByteArrayOutputStream()
        parts.forEach { part ->
            val clean = stripMp3Tags(part)
            output.write(clean)
        }
        return output.toByteArray()
    }

    private fun stripMp3Tags(bytes: ByteArray): ByteArray {
        var start = 0
        var end = bytes.size
        if (bytes.size >= 10 && bytes[0] == 'I'.code.toByte() && bytes[1] == 'D'.code.toByte() && bytes[2] == '3'.code.toByte()) {
            val size = ((bytes[6].toInt() and 0x7f) shl 21) or
                ((bytes[7].toInt() and 0x7f) shl 14) or
                ((bytes[8].toInt() and 0x7f) shl 7) or
                (bytes[9].toInt() and 0x7f)
            start = (10 + size).coerceAtMost(bytes.size)
        }
        if (end - start >= 128 && bytes[end - 128] == 'T'.code.toByte() &&
            bytes[end - 127] == 'A'.code.toByte() && bytes[end - 126] == 'G'.code.toByte()) {
            end -= 128
        }
        return if (end > start) bytes.copyOfRange(start, end) else byteArrayOf()
    }

    fun joinWav(parts: List<ByteArray>): ByteArray {
        require(parts.isNotEmpty()) { "Tidak ada audio untuk digabungkan." }
        val first = parts.first()
        require(first.size >= 44 && String(first.copyOfRange(0, 4)) == "RIFF") { "Format WAV tidak dikenali." }
        val sampleRate = readIntLE(first, 24)
        val channels = readShortLE(first, 22)
        val bitsPerSample = readShortLE(first, 34)
        val byteRate = readIntLE(first, 28)
        val blockAlign = readShortLE(first, 32)
        val pcm = ByteArrayOutputStream()

        parts.forEach { wav ->
            require(wav.size >= 44 && String(wav.copyOfRange(0, 4)) == "RIFF") { "Salah satu bagian bukan WAV." }
            val dataSize = readIntLE(wav, 40).coerceAtLeast(0).coerceAtMost(wav.size - 44)
            pcm.write(wav, 44, dataSize)
        }

        val audio = pcm.toByteArray()
        val out = ByteArrayOutputStream()
        out.write("RIFF".toByteArray())
        writeIntLE(out, 36 + audio.size)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        writeIntLE(out, 16)
        writeShortLE(out, 1)
        writeShortLE(out, channels)
        writeIntLE(out, sampleRate)
        writeIntLE(out, byteRate)
        writeShortLE(out, blockAlign)
        writeShortLE(out, bitsPerSample)
        out.write("data".toByteArray())
        writeIntLE(out, audio.size)
        out.write(audio)
        return out.toByteArray()
    }

    private fun readIntLE(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xff) or ((b[i + 1].toInt() and 0xff) shl 8) or
            ((b[i + 2].toInt() and 0xff) shl 16) or ((b[i + 3].toInt() and 0xff) shl 24)

    private fun readShortLE(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xff) or ((b[i + 1].toInt() and 0xff) shl 8)

    private fun writeIntLE(out: ByteArrayOutputStream, value: Int) {
        out.write(value and 0xff); out.write((value shr 8) and 0xff)
        out.write((value shr 16) and 0xff); out.write((value shr 24) and 0xff)
    }

    private fun writeShortLE(out: ByteArrayOutputStream, value: Int) {
        out.write(value and 0xff); out.write((value shr 8) and 0xff)
    }
}
