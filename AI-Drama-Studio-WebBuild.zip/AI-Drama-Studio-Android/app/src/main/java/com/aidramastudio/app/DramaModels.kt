package com.aidramastudio.app

data class DialogueLine(
    val speaker: String,
    val text: String
)

data class CharacterConfig(
    val name: String,
    val elevenVoiceId: String = "",
    val geminiVoice: String = "Kore"
)

enum class TtsEngine { ELEVENLABS, GEMINI }

data class GeneratedAudio(
    val bytes: ByteArray,
    val extension: String,
    val mimeType: String,
    val chunks: Int
)

object ScriptParser {
    private val linePattern = Regex("^\\s*([^:\\n]{1,60}):\\s*(.*)$")

    fun parse(script: String): List<DialogueLine> {
        val result = mutableListOf<DialogueLine>()
        var speaker: String? = null
        val body = StringBuilder()

        fun flush() {
            val currentSpeaker = speaker?.trim().orEmpty()
            val text = body.toString().trim()
            if (currentSpeaker.isNotBlank() && text.isNotBlank()) {
                result += DialogueLine(currentSpeaker, text)
            }
            body.clear()
        }

        script.lines().forEach { raw ->
            val match = linePattern.matchEntire(raw)
            if (match != null) {
                flush()
                speaker = match.groupValues[1].trim()
                body.append(match.groupValues[2].trim())
            } else if (speaker != null) {
                if (body.isNotEmpty()) body.append('\n')
                body.append(raw.trim())
            }
        }
        flush()
        return result
    }

    fun chunk(lines: List<DialogueLine>, maxChars: Int = 1750): List<List<DialogueLine>> {
        val chunks = mutableListOf<MutableList<DialogueLine>>()
        var current = mutableListOf<DialogueLine>()
        var size = 0

        fun push() {
            if (current.isNotEmpty()) chunks += current
            current = mutableListOf()
            size = 0
        }

        lines.forEach { line ->
            val lineSize = line.text.length + line.speaker.length + 8
            if (lineSize > maxChars) {
                push()
                var remaining = line.text
                while (remaining.isNotBlank()) {
                    val cut = remaining.lastIndexOf(' ', minOf(maxChars - line.speaker.length - 10, remaining.length - 1))
                        .takeIf { it > 0 } ?: minOf(maxChars - line.speaker.length - 10, remaining.length)
                    val piece = remaining.substring(0, cut).trim()
                    if (piece.isNotBlank()) chunks += mutableListOf(DialogueLine(line.speaker, piece))
                    remaining = remaining.substring(cut).trim()
                }
            } else {
                if (size + lineSize > maxChars) push()
                current += line
                size += lineSize
            }
        }
        push()
        return chunks
    }
}
