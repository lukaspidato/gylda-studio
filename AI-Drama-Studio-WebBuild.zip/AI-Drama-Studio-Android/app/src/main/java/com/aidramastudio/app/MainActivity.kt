package com.aidramastudio.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val colors = darkColorScheme(
                primary = Color(0xFFB8A2FF),
                onPrimary = Color(0xFF211443),
                secondary = Color(0xFF8BD7C2),
                background = Color(0xFF10111A),
                surface = Color(0xFF191B28),
                onBackground = Color(0xFFF5F4FA),
                onSurface = Color(0xFFF5F4FA)
            )
            MaterialTheme(colorScheme = colors) {
                Surface(modifier = Modifier.fillMaxSize(), color = colors.background) {
                    DramaStudioScreen(this)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DramaStudioScreen(context: Context) {
    val secureStore = remember { SecureStore(context) }
    val scope = rememberCoroutineScope()
    val characters = remember {
        mutableStateListOf(
            CharacterConfig("Perempuan muda", geminiVoice = "Kore"),
            CharacterConfig("Perempuan tua", geminiVoice = "Aoede"),
            CharacterConfig("Pemuda", geminiVoice = "Puck"),
            CharacterConfig("Kakek", geminiVoice = "Charon"),
            CharacterConfig("Narator", geminiVoice = "Fenrir"),
            CharacterConfig("Tetangga", geminiVoice = "Zephyr")
        )
    }
    var script by remember { mutableStateOf("") }
    var elevenKey by remember { mutableStateOf("") }
    var geminiKey by remember { mutableStateOf("") }
    var engine by remember { mutableStateOf(TtsEngine.ELEVENLABS) }
    var isGenerating by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0) }
    var totalChunks by remember { mutableStateOf(0) }
    var status by remember { mutableStateOf("Siap membuat drama audio.") }
    var savedPath by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        elevenKey = secureStore.get("elevenlabs_key")
        geminiKey = secureStore.get("gemini_key")
    }

    val parsedLines = remember(script) { ScriptParser.parse(script) }
    val speakersInScript = remember(parsedLines) { parsedLines.map { it.speaker }.distinct() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Drama Studio", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("Multi-character audio production", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                },
                actions = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 18.dp)) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF24223B)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Studio drama 30 menit", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Masukkan naskah, pasangkan suara untuk setiap tokoh, lalu buat audio per bagian secara otomatis.", color = Color(0xFFD7D3E8), fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MiniPill("6+ karakter")
                        MiniPill("Auto-chunk")
                        MiniPill("MP3 / WAV")
                    }
                }
            }

            SectionTitle("01", "Pilih mesin suara", Icons.Default.Settings)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = engine == TtsEngine.ELEVENLABS,
                    onClick = { engine = TtsEngine.ELEVENLABS },
                    label = { Text("ElevenLabs · 6 karakter") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = engine == TtsEngine.GEMINI,
                    onClick = { engine = TtsEngine.GEMINI },
                    label = { Text("Gemini · 2 karakter") },
                    modifier = Modifier.weight(1f)
                )
            }
            Text(
                if (engine == TtsEngine.ELEVENLABS)
                    "Direkomendasikan untuk drama dengan 4–6 tokoh. Setiap bagian otomatis dibatasi sekitar 1.750 karakter agar stabil."
                else
                    "Gemini mendukung maksimal 2 suara dalam satu permintaan multi-speaker. Setiap bagian naskah harus berisi paling banyak 2 tokoh.",
                color = MaterialTheme.colorScheme.secondary,
                fontSize = 12.sp
            )

            SectionTitle("02", "Masukkan naskah", Icons.Default.Mic)
            OutlinedTextField(
                value = script,
                onValueChange = { script = it },
                modifier = Modifier.fillMaxWidth().height(250.dp),
                label = { Text("Naskah drama") },
                placeholder = { Text("Perempuan muda: Nenek, siapa yang tinggal di rumah itu?\nPerempuan tua: Jangan pernah mendekati rumah itu.\nKakek: Ada sesuatu yang belum kalian ketahui...") },
                minLines = 8,
                maxLines = 14
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                MiniPill("${parsedLines.size} dialog terbaca")
                MiniPill("${speakersInScript.size} tokoh terdeteksi")
            }
            Text("Format wajib: Nama Tokoh: isi dialog. Baris lanjutan tanpa tanda titik dua akan dianggap bagian dari dialog sebelumnya.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f), fontSize = 11.sp)

            SectionTitle("03", "Atur karakter dan suara", Icons.Default.Mic)
            Text("Nama karakter harus sama persis dengan nama yang digunakan di dalam naskah.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f), fontSize = 12.sp)
            characters.forEachIndexed { index, character ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D2B)), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("TOKOH ${index + 1}", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = character.name,
                            onValueChange = { characters[index] = character.copy(name = it) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Nama tokoh") },
                            singleLine = true
                        )
                        if (engine == TtsEngine.ELEVENLABS) {
                            OutlinedTextField(
                                value = character.elevenVoiceId,
                                onValueChange = { characters[index] = character.copy(elevenVoiceId = it) },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("ElevenLabs Voice ID") },
                                placeholder = { Text("Tempel Voice ID dari ElevenLabs") },
                                singleLine = true
                            )
                        } else {
                            OutlinedTextField(
                                value = character.geminiVoice,
                                onValueChange = { characters[index] = character.copy(geminiVoice = it) },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Nama voice Gemini") },
                                singleLine = true
                            )
                        }
                    }
                }
            }
            Button(onClick = { characters.add(CharacterConfig("Karakter ${characters.size + 1}")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Tambah karakter")
            }

            SectionTitle("04", "Kunci API", Icons.Default.Settings)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D2B)), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = elevenKey,
                        onValueChange = { elevenKey = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("ElevenLabs API Key") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = geminiKey,
                        onValueChange = { geminiKey = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Google Gemini API Key") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            secureStore.put("elevenlabs_key", elevenKey.trim())
                            secureStore.put("gemini_key", geminiKey.trim())
                            status = "Kunci API disimpan terenkripsi di perangkat ini."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Simpan kunci API dengan aman") }
                    Text("Kunci API tidak ditanam di dalam kode APK. Untuk pemakaian pribadi, kunci disimpan terenkripsi di perangkat.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                }
            }

            SectionTitle("05", "Generate audio", Icons.Default.AutoAwesome)
            Button(
                onClick = {
                    if (isGenerating) return@Button
                    val key = if (engine == TtsEngine.ELEVENLABS) elevenKey.trim() else geminiKey.trim()
                    if (key.isBlank()) {
                        status = "Masukkan dan simpan API key untuk mesin suara yang dipilih."
                        return@Button
                    }
                    if (parsedLines.isEmpty()) {
                        status = "Naskah belum terbaca. Gunakan format Nama Tokoh: dialog."
                        return@Button
                    }
                    val currentMap = characters.associateBy { it.name.trim() }
                    val missing = speakersInScript.filter { it !in currentMap }
                    if (missing.isNotEmpty()) {
                        status = "Tokoh belum didaftarkan: ${missing.joinToString(", ")}"
                        return@Button
                    }
                    secureStore.put("elevenlabs_key", elevenKey.trim())
                    secureStore.put("gemini_key", geminiKey.trim())
                    isGenerating = true
                    progress = 0
                    totalChunks = ScriptParser.chunk(parsedLines).size
                    status = "Menyiapkan ${parsedLines.size} dialog..."
                    savedPath = ""
                    scope.launch {
                        try {
                            val result = TtsClient().generate(engine, key, parsedLines, currentMap) { done, total ->
                                progress = done
                                totalChunks = total
                                status = "Memproses bagian $done dari $total..."
                            }
                            val filename = "AI_Drama_${System.currentTimeMillis()}.${result.extension}"
                            val uri = withContext(Dispatchers.IO) { saveAudioToMusic(context, result.bytes, filename, result.mimeType) }
                            savedPath = uri
                            status = "Selesai! ${result.chunks} bagian digabungkan. Audio tersimpan di folder Musik/AI Drama Studio."
                        } catch (error: Exception) {
                            status = error.message ?: "Terjadi kesalahan saat membuat audio."
                        } finally {
                            isGenerating = false
                        }
                    }
                },
                enabled = !isGenerating,
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Sedang membuat audio...")
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("GENERATE DRAMA AUDIO", fontWeight = FontWeight.Bold)
                }
            }
            if (isGenerating && totalChunks > 0) {
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { progress.toFloat() / totalChunks.toFloat() },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("$progress / $totalChunks bagian", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202235)), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("STATUS", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    Text(status, fontSize = 13.sp)
                    if (savedPath.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(Modifier.width(6.dp))
                            Text(savedPath, fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
            HorizontalDivider(color = Color(0xFF333548))
            Text("Catatan: pemakaian TTS mengikuti kuota dan biaya akun Google/ElevenLabs kamu. Aplikasi ini tidak menyediakan kuota suara.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SectionTitle(number: String, title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(
            modifier = Modifier.size(30.dp).background(Color(0xFF302A4E), RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center
        ) { Text(number, fontSize = 11.sp, color = Color(0xFFD2C5FF), fontWeight = FontWeight.Bold) }
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun MiniPill(text: String) {
    Box(Modifier.background(Color(0xFF37334E), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 5.dp)) {
        Text(text, color = Color(0xFFE2DCFF), fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

private fun saveAudioToMusic(context: Context, bytes: ByteArray, filename: String, mimeType: String): String {
    val resolver = context.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.Audio.Media.DISPLAY_NAME, filename)
        put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/AI Drama Studio")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
    }
    val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    val uri = resolver.insert(collection, values) ?: throw IllegalStateException("Tidak dapat membuat file audio di penyimpanan.")
    try {
        resolver.openOutputStream(uri)?.use { it.write(bytes) }
            ?: throw IllegalStateException("Tidak dapat menulis file audio.")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val complete = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            resolver.update(uri, complete, null, null)
        }
    } catch (e: Exception) {
        resolver.delete(uri, null, null)
        throw e
    }
    return uri.toString()
}
