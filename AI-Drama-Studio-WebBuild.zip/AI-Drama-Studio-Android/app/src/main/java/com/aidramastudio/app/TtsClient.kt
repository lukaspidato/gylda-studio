package com.aidramastudio.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Base64
import java.util.concurrent.TimeUnit

class TtsClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(240, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generate(
        engine: TtsEngine,
        apiKey: String,
        lines: List<DialogueLine>,
        characters: Map<String, CharacterConfig>,
        onProgress: (Int, Int) -> Unit
    ): GeneratedAudio = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "API key belum diisi." }
        require(lines.isNotEmpty()) { "Naskah belum berisi dialog dengan format Nama: dialog." }

        val chunks = ScriptParser.chunk(lines)
        val outputs = mutableListOf<ByteArray>()
        chunks.forEachIndexed { index, chunk ->
            val bytes = when (engine) {
                TtsEngine.ELEVENLABS -> generateElevenLabs(apiKey, chunk, characters)
                TtsEngine.GEMINI -> generateGemini(apiKey, chunk, characters)
            }
            outputs += bytes
            withContext(Dispatchers.Main) { onProgress(index + 1, chunks.size) }
        }

        when (engine) {
            TtsEngine.ELEVENLABS -> GeneratedAudio(
                bytes = AudioJoiner.joinMp3(outputs),
                extension = "mp3",
                mimeType = "audio/mpeg",
                chunks = chunks.size
            )
            TtsEngine.GEMINI -> GeneratedAudio(
                bytes = AudioJoiner.joinWav(outputs),
                extension = "wav",
                mimeType = "audio/wav",
                chunks = chunks.size
            )
        }
    }

    private fun generateElevenLabs(
        apiKey: String,
        lines: List<DialogueLine>,
        characters: Map<String, CharacterConfig>
    ): ByteArray {
        val inputs = JSONArray()
        lines.forEach { line ->
            val character = characters[line.speaker]
                ?: throw IllegalArgumentException("Karakter '${line.speaker}' belum didaftarkan pada daftar karakter.")
            if (character.elevenVoiceId.isBlank()) {
                throw IllegalArgumentException("Voice ID ElevenLabs untuk '${line.speaker}' belum diisi.")
            }
            inputs.put(JSONObject().put("text", line.text).put("voice_id", character.elevenVoiceId.trim()))
        }
        val uniqueVoices = lines.mapNotNull { characters[it.speaker]?.elevenVoiceId?.trim() }.distinct()
        require(uniqueVoices.size <= 10) { "ElevenLabs mendukung maksimal 10 voice ID unik per request." }

        val body = JSONObject()
            .put("inputs", inputs)
            .put("model_id", "eleven_v4")
            .put("language_code", "id")
            .toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-dialogue?output_format=mp3_44100_128")
            .header("xi-api-key", apiKey)
            .header("Accept", "audio/mpeg")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val message = response.body?.string().orEmpty().take(600)
                throw IllegalStateException("ElevenLabs (${response.code}): ${message.ifBlank { response.message }}")
            }
            return response.body?.bytes() ?: throw IllegalStateException("ElevenLabs tidak mengembalikan audio.")
        }
    }

    private fun generateGemini(
        apiKey: String,
        lines: List<DialogueLine>,
        characters: Map<String, CharacterConfig>
    ): ByteArray {
        val speakerNames = lines.map { it.speaker }.distinct()
        require(speakerNames.size <= 2) {
            "Adegan ini memuat ${speakerNames.size} karakter. Gemini multi-speaker hanya mendukung maksimal 2 karakter per request. Pilih ElevenLabs untuk adegan ini atau pisahkan adegannya."
        }

        speakerNames.forEach { name ->
            require(characters[name] != null) { "Karakter '$name' belum didaftarkan." }
            require(characters[name]?.geminiVoice?.isNotBlank() == true) { "Voice Gemini untuk '$name' belum diisi." }
        }

        val aliases = speakerNames.mapIndexed { index, name -> name to "SPEAKER${index + 1}" }.toMap()
        val content = JSONArray()
        lines.forEach { line ->
            val annotation = JSONObject().put("type", "speech_metadata")
            if (speakerNames.size > 1) annotation.put("speaker", aliases[line.speaker])
            content.put(
                JSONObject()
                    .put("type", "text")
                    .put("text", line.text)
                    .put("annotations", JSONArray().put(annotation))
            )
        }

        val speechConfig = if (speakerNames.size == 1) {
            JSONArray().put(JSONObject().put("voice", characters[speakerNames.first()]!!.geminiVoice.trim()))
        } else {
            val speakers = JSONArray()
            speakerNames.forEach { name ->
                speakers.put(
                    JSONObject()
                        .put("speaker", aliases[name])
                        .put("voice", characters[name]!!.geminiVoice.trim())
                )
            }
            JSONObject().put("speakers", speakers)
        }

        val payload = JSONObject()
            .put("model", "gemini-3.8-flash-tts")
            .put("input", JSONArray().put(JSONObject()
                .put("type", "user_input")
                .put("content", content)))
            .put("response_format", JSONObject().put("type", "audio"))
            .put("generation_config", JSONObject().put("speech_config", speechConfig))

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/interactions")
            .header("x-goog-api-key", apiKey)
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val responseText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("Gemini (${response.code}): ${responseText.take(700)}")
            }
            val root = JSONObject(responseText)
            val direct = root.optJSONObject("output_audio")?.optString("data").orEmpty()
            if (direct.isNotBlank()) return Base64.getDecoder().decode(direct)

            val steps = root.optJSONArray("steps")
            if (steps != null) {
                for (i in steps.length() - 1 downTo 0) {
                    val contentItems = steps.optJSONObject(i)?.optJSONArray("content") ?: continue
                    for (j in contentItems.length() - 1 downTo 0) {
                        val item = contentItems.optJSONObject(j) ?: continue
                        val data = item.optString("data")
                        if (item.optString("type") == "audio" && data.isNotBlank()) {
                            return Base64.getDecoder().decode(data)
                        }
                    }
                }
            }
            throw IllegalStateException("Gemini tidak mengembalikan data audio yang dikenali.")
        }
    }
}
